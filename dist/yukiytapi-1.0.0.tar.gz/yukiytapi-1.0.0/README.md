# 🎵 YukiYTAPI — Python SDK

[![PyPI Version](https://img.shields.io/pypi/v/yukiytapi.svg)](https://pypi.org/project/yukiytapi/)
[![Python Versions](https://img.shields.io/pypi/pyversions/yukiytapi.svg)](https://pypi.org/project/yukiytapi/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

Official, ultra-fast Python SDK for the **Yuki YouTube Media & Streaming Engine** (`https://music.yukiapi.site`).

Designed for **Telegram Music Bots (Yukki, AnonX, Fallen)**, Discord Bots, PyTgCalls, GroupCall streaming, and high-speed audio/video downloading.

---

## ⚡ Key Features

- 🏎️ **Ultra-Fast 3-Way Async Search Race**: Sub-second search & metadata resolution.
- 🎧 **Instant Streaming & Token Auth**: Direct stream URLs ready for PyTgCalls / FFmpeg.
- 📥 **Atomic Disk Downloads**: High-speed chunked MP3 & 720p MP4 downloads.
- 🔄 **1-Line Drop-in Compatibility**: Replace 1300+ lines of custom `Youtube.py` in Yukki / AnonX / Fallen bots with 1 line.
- 🪶 **Lightweight**: Zero heavy scrapers on client machines (pure `aiohttp`).
- 💻 **CLI Utility**: Comes with `yuki-dl` terminal tool.

---

## 📦 Installation

```bash
pip install yukiytapi
```

---

## 🚀 Quickstart

### 1. Modern Async API (Pyrogram, Telethon, discord.py, aiogram)

```python
import asyncio
from yukiytapi import YukiAPI

async def main():
    async with YukiAPI() as yuki:
        # 1. Search tracks
        results = await yuki.search("Kesariya", limit=5)
        for t in results:
            print(f"{t.title} ({t.duration}) - {t.link}")

        # 2. Get track details (supports tuple unpacking!)
        title, dur_min, dur_sec, thumb, vidid = await yuki.details("Kesariya")
        print(f"Playing: {title} [{dur_min}]")

        # 3. Get direct streamable URL for PyTgCalls / GroupCall
        stream_url = await yuki.get_stream("Kesariya", type="audio")
        print(f"Stream URL: {stream_url}")

        # 4. Download file to local disk (MP3 or MP4)
        file_path = await yuki.download("Kesariya", type="audio", output_dir="downloads")
        print(f"Downloaded to: {file_path}")

asyncio.run(main())
```

---

## 🤖 1-Line Drop-in Migration for Telegram Music Bots

If you run a Telegram Music Bot (YukkiMusic, AnonXMusic, FallenMusic, etc.), you can **delete your entire 1300+ line `platforms/Youtube.py`** and replace it with:

```python
# In your bot's platforms/Youtube.py:
from yukiytapi.compat import YouTubeAPI

YouTube = YouTubeAPI()
```

That's literally it! All your bot commands (`track`, `details`, `title`, `duration`, `thumbnail`, `search`, `download`, `formats`, `playlist`) will work seamlessly out of the box with zero server load.

---

## 🖥️ Command Line Interface (CLI)

```bash
# Download audio (MP3)
yuki-dl "Kesariya"

# Download video (MP4)
yuki-dl "Kesariya" --video

# Search tracks
yuki-dl --search "Arijit Singh" --limit 5

# Print direct stream URL
yuki-dl --url "Kesariya"
```

---

## 📄 License

MIT © [SUDEEPBOTS](https://github.com/SUDEEPBOTS)
